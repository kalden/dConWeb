$input_file="balanced_benchmark_3_all_methods";
$output_file="benchmark_3.html";

open (FILE_INPUT, $input_file) || die "Cannot open $input_file for reading \n";

@line = <FILE_INPUT>;
close(FILE_INPUT);

'rm -f $fileout' if -e $fileout;
open (FILEOUT, ">$output_file") || die "Cannot open $output_file for writing \n";

foreach $newline (@line) {
	$newline =~ s/\n/<br>\n/g;
	print FILEOUT $newline;
}
