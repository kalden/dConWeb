<?php
	$structId = strtoupper($_GET["pdbId"]);
	$chainId = $_GET["chain"];
	
	// the methods are received as true or false dependent if the box is ticked - these are put into a hash table
	// with the method as the key so these can be retrieved later
	$selMeths = array();

	$selMeths["CATH"] = $_GET["CATH"];
	$selMeths["SCOP"] = $_GET["SCOP"];
	$selMeths["PUU"] = $_GET["PUU"];
	$selMeths["dp"] = $_GET["dp"];
	$selMeths["pdp"] = $_GET["pdp"];
	$selMeths["DDomain"] = $_GET["DDomain"];
	$selMeths["DHcL"] = $_GET["DHcL"];
	$selMeths["NCBI"] = $_GET["NCBI"];
	$selMeths["Dodis"] = $_GET["Dodis"];

	include("components/environment.php");
	include("components/menu.php");
	include("components/resultssidemenu.php");
	
	PrintHeader("Results: Comparison of Assigned Domains");
	
	print '
	  <table width="95%"  border="0" cellspacing="0" cellpadding="0">
		<tr align="left">
		  <td valign="top" width="242">';
		  PrintSideMenuBox("Results",ResultSideMenuItems("Results","Domain Assignment Summary",$structId,$_GET["chain"],$selMeths["CATH"],$selMeths["SCOP"],$selMeths["DDomain"],$selMeths["Dodis"],$selMeths["PUU"],$selMeths["DHcL"],$selMeths["dp"],$selMeths["pdp"],$selMeths["NCBI"]));
		  print '
		  </td>
		  <td valign="top" align="left">
        <div id="textheading">Domain Assignment by Method</div>

	<div id="textinfo">
	<div style="padding-left:20px; padding-top: 8px; padding-bottom: 8px; width: 650px;">';
	
	// print selected protein and chain
	print '<b>Selected Protein:</b> '.$structId. ' <b>Chain:</b> '.$_GET["chain"].'<BR></div>';
	
	// connect to database
	$dbhost = '137.110.134.140:8888';
	$dbuser = 'domains';
	$dbpass = 'ucsd';
	$dbname = 'domains';

	$con = mysql_connect($dbhost,$dbuser,$dbpass);
	if (!$con)
	  {
	  die('Could not connect: ' . mysql_error());
	  }

	mysql_select_db($dbname, $con);

	// get the start of the chain - needed for the drawing function - ensures all the methods start at same point
	$getChainStart = mysql_query("SELECT MIN(start) FROM automeths WHERE domain REGEXP '^".$structId.$chainId."'");
	while($row = mysql_fetch_array($getChainStart))
	{
		$chainStart = $row['MIN(start)'];
	}	

	// get the end of the chain - needed for the drawing function - ensures all the methods end at same point
	$getChainEnd = mysql_query("SELECT MAX(end) FROM automeths WHERE domain REGEXP '^".$structId.$chainId."' ORDER by end DESC");
	while($row = mysql_fetch_array($getChainEnd))
	{
		$chainEnd = $row['MAX(end)'];
	}

	// now get all the domain assignments for this chain for the graph
	$domains = mysql_query("SELECT * FROM automeths WHERE domain REGEXP '^".$structId.$chainId."' ORDER BY method,start");
	$num_results = mysql_num_rows($domains);

	// now get the assignments again, but this time sort differently, this is for the fragment table on the page
	$domainstoprint = mysql_query("SELECT * FROM automeths WHERE domain REGEXP '^".$structId.$chainId."' ORDER BY method,domain,fragmentNo");

	// add the applet and send start/end parameters
	print'
 	<APPLET ARCHIVE="Graph2.jar" CODE="pDomains/MethodGraph2.class" WIDTH=700 HEIGHT=300>
		<PARAM NAME="pdbId" VALUE="'.$structId.$chainId.'">
		<PARAM NAME="start" VALUE="'.$chainStart.'">
		<PARAM NAME="end" VALUE="'.$chainEnd.'">';

	// now need to generate the parameters for each method to send to the display applet
	$num_rows = 1;

	while($row = mysql_fetch_array($domains))   // for each method
 	{
		$struct = $row['domain'];
		$fragment = $row['fragmentNo'];
		$start = $row['start'];
		$end = $row['end'];
		$method = $row['method'];
	
		if($selMeths[$method]=="true")      // if the user has selected this method
		{
			// create parameter tags to send required info to drawing package
			print '<PARAM NAME="domain'.($num_rows-1).'" VALUE="'.$struct.'">
		   		<PARAM NAME="fragment'.($num_rows-1).'" VALUE="'.$fragment.'">
		   		<PARAM NAME="start'.($num_rows-1).'" VALUE="'.$start.'">
		   		<PARAM NAME="end'.($num_rows-1).'" VALUE="'.$end.'">
		   		<PARAM NAME="method'.($num_rows-1).'" VALUE="'.$method.'">';

  			$num_rows = $num_rows +1;
  		}
  
	}
	// send the number of results as this is needed by the applet
	print '<PARAM NAME="numResults" VALUE="'.$num_results.'">
		</APPLET>';

	// now create a text table to display all the fragment positions

	print '<div id="textinfo">
	<div style="padding-left:20px; padding-top: 8px; padding-bottom: 8px; width: 650px;">
	<b>Domain Boundary Position Summary:</b>
	</div>

	<div style="padding-left:50px; padding-top: 8px; padding-bottom: 8px; width: 650px;">
	<table>
	<tr bgcolor="#6887C4"><th width="110" align=center>Method<th width="110" align=center>Domain Id<th width="400" align=center>Fragment</tr><table>';
	$test = 1;
	$fragmentPrint = null;

	// as the results need grouping by domain, the currentMethod and domain need tracking
	$row = mysql_fetch_array($domainstoprint);
	$currentMethod = $row['method'];
	$currentDomain = $row['domain'];
	$fragmentPrint = $row['start'].'-'.$row['end'];

	print'<tr><td width="110" align=center>'.$currentMethod.'</td>';
	while($row = mysql_fetch_array($domainstoprint))
	{
		$struct = $row['domain'];
		$fragment = $row['fragmentNo'];
		$start = $row['start'];
		$end = $row['end'];
		$method = $row['method'];
	
		if($selMeths[$method]=="true")         // the user has selected the method
		{
			if($method==$currentMethod) 
			{	
				if($currentDomain==$struct)         // still looking at the same domain so add to string
				{
					$fragmentPrint = $fragmentPrint.' , '.$start.'-'.$end;
				}
				else      // different domain, so print string containing all fragments of last domain
				{
					print'<td width="110" align=center>'.$currentDomain.'</td>
						<td width="400">'.$fragmentPrint.'</td></tr>';
					$currentDomain = $struct;                          // set to start new domain
					$fragmentPrint = $start.'-'.$end;
					print'<tr><td width="110" align=center>';
				}
			}
			else           // different method, so currentmethos needs changing & method printing
			{
				$currentMethod=$method;
				print'<td width="110" align=center>'.$currentDomain.'</td>
					<td width="400">'.$fragmentPrint.'</td></tr>';
				$currentDomain = $struct;
				$fragmentPrint = $start.'-'.$end;
				print'<tr><td width="110" align=center>'.$method.'</td>';
			}
		}
	}
	//print final domain that not yet output
	print'<td width="110" align=center>'.$currentDomain.'</td>
		<td width="400">'.$fragmentPrint.'</td></tr>';
	

	mysql_close($con);

	print'</table></td>
	</tr>
	</table>
	<br>
	<br>
	<br>';	
	
	PrintFooter();
?>
